<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
// dat ten route trang
Route::get('/product',[
	'as'	=>	'product.show',
	'uses'	=>	'showproduct@show'
	]);
Route::get('/category',[
	'as'	=>	'category.show',
	'uses'	=>	'CateController@showcate'
	]);

Route::get('/shoppingcart',[
	'as'	=>	'shoppingcart.show',
	'uses'	=> 	'ShowShoppingCart@show'
	]);

Route::get('/checkout',[
	'as'	=>	'checkout.show',
	'uses'	=>	'Checkout@show'
	]);

Route::get('/login',[
	'as'	=>	'login.show',
	'uses'	=>	'Account@login'
	]);

Route::get('/register',[
	'as'	=>	'register.show',
	'uses'	=>	'Account@register'
	]);

Route::get('/contact',[
	'as'	=>	'contact.show',
	'uses'	=>	'Contact@show'
	]);
// Authentication routes
Route::get('auth/login','Auth\AuthController@getLogin');


Route::group(['prefix'=>'admin'],function()
{
	Route::group(['prefix'=>'cate'],function()
	{
		Route::get('add',['as'=>'getAdd','uses'=>'CateController@getAdd']);
		Route::post('add',['as'=>'postAdd','uses'=>'CateController@postAdd']);
	});
});

Route::get('/trang-chu',function()
{
	return view('user.pages.home');
});



