<section class="slider">
    <div class="container">
      <div class="flexslider" id="mainslider">
        <ul class="slides">
          <li>
            <img src="img/banner1.jpg" alt="" />
          </li>
          <li>
            <img src="img/banner2.jpg" alt="" />
          </li>
          <li>
            <img src="img/banner1.jpg" alt="" />
          </li>
          <li>
            <img src="img/banner2.jpg" alt="" />
          </li>
        </ul>
      </div>
    </div>
  </section>