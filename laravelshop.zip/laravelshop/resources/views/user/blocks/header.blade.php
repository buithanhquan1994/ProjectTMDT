<div class="headerstrip">
    <div class="container">
      <div class="row">
        <div class="span12">
          <a href="#" class="logo pull-left"><img src="img/logo.png" alt="SimpleOne" title="SimpleOne"></a>
          <!-- Top Nav Start -->
          <div class="pull-left">
            <div class="navbar" id="topnav">
              <div class="navbar-inner">
                <ul class="nav" >
                  <li><a class="home" href="{{ url('/trang-chu') }}">Home</a>
                  </li>
                  <li><a class="myaccount" href="#">My Account</a>
                  </li>
                  <li><a class="shoppingcart" href="{{ route('shoppingcart.show')}}">Shopping Cart</a>
                  </li>
                  <li><a class="checkout" href="{{ route('checkout.show')}}">CheckOut</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <!-- Top Nav End -->
        </div>
      </div>
    </div>
  </div>
  <div class="container">