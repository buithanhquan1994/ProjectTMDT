<div id="categorymenu">
      <nav class="subnav">
        <ul class="nav-pills categorymenu">
          <li><a class="active"  href="{{ url('/trang-chu') }}">Home</a>
       
          </li>
          <li><a href="{{ route('product.show') }}">Products</a>
            <div>
              <ul>
                <li><a href="product.html">Product style 1</a>
                </li>
                <li><a href="product2.html">Product style 2</a>
                </li>
                <li><a href="#"> Women's Accessories</a>
                </li>
                <li><a href="#">Men's Accessories <span class="label label-success">Sale</span>
                  </a>
                </li>
                <li><a href="#">Dresses </a>
                </li>
                <li><a href="#">Shoes <span class="label label-warning">(25)</span>
                  </a>
                </li>
                <li><a href="#">Bags <span class="label label-info">(new)</span>
                  </a>
                </li>
                <li><a href="#">Sunglasses </a>
                </li>
              </ul>
              <ul>
                <li><img style="display:block" src="img/proudctbanner.jpg" alt="" title="" >
                </li>
              </ul>
            </div>
          </li>
          <li><a  href="{{ url('/category') }}">Categories</a>
          </li>
          <li><a href="{{ url('/shoppingcart') }}">Shopping Cart</a>
          </li>
          <li><a href="{{ route('checkout.show') }}">Checkout</a>
          </li>
          <li><a href="">My Account</a>
            <div>
              <ul>
                <li><a href="myaccount.html">My Account</a>
                </li>
                <li><a href="{{ route('login.show') }}">Login</a>
                </li>
                <li><a href="{{ route('register.show') }}">Register</a>
                </li>
              </ul>
            </div>
          </li>
         
          <li><a href="{{ route('contact.show') }}">Contact</a>
          </li>         
        </ul>
      </nav>
    </div>